import Web3 from 'web3';

const contractABI = [{ "inputs": [{ "internalType": "address", "name": "add", "type": "address" }], "name": "isRegistered", "outputs": [{ "internalType": "bool", "name": "", "type": "bool" }], "stateMutability": "view", "type": "function" }, { "inputs": [{ "internalType": "address", "name": "add", "type": "address" }], "name": "register", "outputs": [], "stateMutability": "nonpayable", "type": "function" }];

// const web3 = new Web3('https://sepolia.infura.io/v3/fb389551167c471794456f68e828c29a');
const web3 = new Web3(new Web3.providers.HttpProvider("https://sepolia.infura.io/v3/fb389551167c471794456f68e828c29a"));


// const account1 = '0x9de2E0Cb2DDEEa396092A3E5ab6Ff9af5976e631';
// const account2 = '0xd5bce38Bac4F70CAFAA5bef40DcCA175EcE71e58';
const account3 = '0x898A1b0a948719c2A756BA472EcbCD53569b9F00';
const privateKey3 = 'bcdab566d460b6f3b84173287c979a86d5f08e421d2e5990548b4ebadd562212';
const contractAddress = '0xF0f15C2132ba5Ba271dB661e26054DD74E48a32d';
const contract = new web3.eth.Contract(contractABI, contractAddress);


export const getActBal = async (address) => {
    const totalBalnce = await web3.eth.getBalance(address);
    return web3.utils.fromWei(totalBalnce, "ether");
}

export const isRegistered = async (add) => {
    console.log('isRegistered');
    return await contract.methods.isRegistered(add).call();
}

export const register = async (add) => {
    console.log('Register');
    const nonce = await web3.eth.getTransactionCount(account3, 'latest');
    const data = contract.methods.register(add).encodeABI();
    const transaction = {
        chainId: web3.utils.toHex(11155111),
        from: account3,
        to: contractAddress,
        gasLimit: web3.utils.toHex(521000),
        gasPrice: web3.utils.toHex(41 * 1e9), // 41 Gwei
        nonce: web3.utils.toHex(nonce),
        data: data
    };
    const signedTx = await web3.eth.accounts.signTransaction(transaction, privateKey3);

    const receipt = await web3.eth
        .sendSignedTransaction(
            signedTx.rawTransaction,
            async (err, data) => {
                if (err) {
                    console.error("sendSignedTransaction error", err);
                    return err;
                }
                else {
                    console.log("The hash of your transaction is: ", data);
                    return data;
                }
            }
        )
        .on("receipt", receipt => console.log("receipt", receipt));
    return receipt.transactionHash;
}

    // web3.eth.sendSignedTransaction(signedTx.rawTransaction, function (error, hash) {
    //     if (!error) {
    //         console.log("🎉 The hash of your transaction is: ", hash, "\n Your Transaction processed successfully.");
    //         return true;
    //     } else {
    //         console.log("❗Something went wrong while submitting your transaction:", error);
    //         return false;
    //     }
    // });

    /*const res = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
    if(!res){
        console.log("🎉 The hash of your transaction is: ", res.hash, "\n Your Transaction processed successfully.");
        return true;
    }else{
        console.log("❗Something went wrong while submitting your transaction:", res);
        return false;
    } */