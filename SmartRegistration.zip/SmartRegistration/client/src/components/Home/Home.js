import React, { useState } from 'react';
import './Home.css';

import {getActBal, isRegistered,register} from '../../contract/index';  


const Home = () => {
    const [result , setResult] = useState(false);
    const [msg, setMsg] = useState('');
    let reply = 'No result currently.';

    const handleRegister =async () => { 
        const address = document.getElementById('add').value;
        const res =await register(address);
        setMsg("https://sepolia.etherscan.io/tx/"+res);
        setResult(true);
    }
    
    const handleRegistered = async () => {
        const address = document.getElementById('add').value;
        const res =await isRegistered(address);
        setMsg(res);
        setResult(true);
    }

    const getBalance = async () => {
        const address = document.getElementById('add').value;
        const bal =await getActBal(address);
        setMsg(bal);
        setResult(true);
    }

    return (
        <div className='Container'>
            <input id='add' type='text' className='inputAddress' placeholder='Enter the Address' />
            <div className='btnContainer'>
                <button onClick={handleRegistered} className='btnChk'>Check?</button>
                <button onClick={handleRegister} className='btnReg'>Register</button>
            </div>
            {
                result && (
                    <div className='resDiv'>
                        <input className='resIp' type='text' value={msg} disabled />
                    </div>
                )
            }
        </div>
    )
}

export default Home;