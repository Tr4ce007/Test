import React from "react";
import './Navbar.css';

const Navbar = () => {
    return (
        <div className="connectDiv">
            <input className='titleText' value ='Register Now' disabled/>
            <button className="connectBtn">Connect</button>
        </div>
    );
};

export default Navbar;
