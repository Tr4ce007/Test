// krypt alchemy https://eth-sepolia.g.alchemy.com/v2/ik1ROUowSTgusIt_AvNqHKXpSKIWcWuP
//Transactions deployed to: 0xBC6759017B543C4A4aDb56028752f78d96c91A98
// Krypt2 -- https://eth-sepolia.g.alchemy.com/v2/Vaz4tRGuBzxxM42rEEwbrAns8wGdCcV5
// Transactions deployed to:  0xdfccE690a0D5a907E75D4959284251775727fE13

// krypt goerli -- https://eth-goerli.g.alchemy.com/v2/gNUY52i6UvKTkIAbl15S47a-_WoaJ0Xn
// Transactions deployed to:  

require('@nomiclabs/hardhat-waffle');
require("@nomiclabs/hardhat-ethers");


module.exports = {
  solidity:'0.8.0',
  networks:{
    goerli:{
      url: 'https://eth-goerli.g.alchemy.com/v2/gNUY52i6UvKTkIAbl15S47a-_WoaJ0Xn',
      accounts:['64ed0fb605276fbe2d51ba4396991e1e9ae685723fada51e34fa68aa4d03f757']
    }
  }
}