
import abi from './Transactions.json';

export const contractABI = abi.abi;
export const contractAddress = '0xdfccE690a0D5a907E75D4959284251775727fE13';