import Web3 from 'web3';
const ContractAbi = require('./abi.json');

const web3 = new Web3(window.ethereum);

const ContractAddress = '0xEcf25d4581fEc4B6b5C501c96FA640d1D26f684f';

let contract ;

export let  connectedAddress = '';

export const connectWallet = async () => {     
    if(window.ethereum !== undefined){
        const Accounts = await window.ethereum.request({method: 'eth_requestAccounts'});
        connectedAddress = Accounts[0];
        contract= new web3.eth.Contract(ContractAbi,ContractAddress);
        return true;
    }
    else{
        alert("install metamask");
        return false;
    }   
}

export const getData = async (add) => {
    const res = await contract.methods.getData(add).call();
    return res;
}

export const setData = async (data) => {
    const txObject = {
        from:connectedAddress,
        to:ContractAddress,
        gas: 500000,
        data: contract.methods.setData(data.name,data.phone,data.email,data.aadhar).encodeABI(),
    };

    const receipt = await web3.eth.sendTransaction(txObject)
    .on("receipt", receipt => console.log("receipt", receipt));
    return receipt.transactionHash;
}