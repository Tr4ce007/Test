import './App.css';
import {useState} from 'react';
import Home from './Home/Home';
import Navbar from './Navbar/Navbar';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [isConnected, setIsConnected]=useState(false);

  const handleConnectionStatus = () => {
    setIsConnected(true);
  }

  const Connect = () =>(
    <input placeholder='Connect Your Wallet to Continue.' 
    disabled
    className="text-center my-9 w-full rounded-sm p-8 outline-none bg-transparent text-white border-none text-6xl white-glassmorphism"/>
  );

  return (
    <div className="gradient-bg-welcome h-screen">
    <Navbar handleConnectionStatus={handleConnectionStatus}/>
    {isConnected && <Home/>}
    {!isConnected && <Connect/>}
    </div>
  );
}

export default App;

// Aadhar Number => 942663593552
