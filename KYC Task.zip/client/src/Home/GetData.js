import { useState } from 'react';
import { getData } from '../Web3/web3';

const Input = ({ placeholder, name, type, value, handleChange, disable }) => (
    <input
        placeholder={placeholder}
        type={type}
        value={value}
        onChange={(e) => handleChange(e, name)}
        disabled={disable}
        className="text-center my-5 w-full rounded-sm p-2 outline-none bg-transparent text-white border-none text-2xl white-glassmorphism"
    />
);

const Output = ({ name, value }) => (
    <div className='flex'>
        <input
            placeholder='Name'
            value={name}
            disabled
            className="text-center my-2 w-30 rounded-sm p-2 outline-none bg-transparent text-white border-none text-2xl white-glassmorphism"
        />
        <input
            value={value}
            disabled
            className="text-center my-2 w-full rounded-sm p-2 outline-none bg-transparent text-white border-none text-2xl white-glassmorphism"
        />
    </div>
);

const GetData = () => {
    const [add, setAdd] = useState('');
    const [resultData, setResultData] = useState([]);
    const [isResult,setIsResult] = useState(false);

    const handleChange = (e, name) => {
        setAdd(e.target.value);
    }

    const helper = () => {
        console.log(resultData);
    }

    const handleSubmit = async () => {
        const res = await getData(add);
        setResultData(prevArray =>[...prevArray,res[0]]);
        setResultData(prevArray =>[...prevArray,res[1]]);
        setResultData(prevArray =>[...prevArray,res[2]]);
        setResultData(prevArray =>[...prevArray,res[3]]);
        setIsResult(true);
    }

    return (
        <div>
            <Input placeholder="Enter your Address" name="add" type="text" handleChange={handleChange} />
            <button
                type="button" onClick={handleSubmit}
                className="text-white text-3xl w-full mt-2 border-[1px] p-2 border-[#3d4f7c] hover:bg-[#3d4f7c] rounded-full cursor-pointer">
                Fetch Your Details
            </button>
            {isResult && 
                ["Name","Phone","Email","Aadhar"].map((item,index) =>(<Output name={item} value={resultData[index]}/>))
            }
        </div>
    );
}

export default GetData;