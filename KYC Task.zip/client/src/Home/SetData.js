import {useState} from 'react';
import {aadharValidation, nameValidation, emailValidation, phoneValidation} from '../Validator/Validator';
import {setData} from '../Web3/web3';

const Input = ({ placeholder, name, type, value, handleChange , disable}) => (
    <input
      placeholder={placeholder}
      type={type}
      value={value}
      onChange={(e) => handleChange(e, name)}
      disabled={disable}
      className="text-center my-2 w-full rounded-sm p-2 outline-none bg-transparent text-white border-none text-2xl white-glassmorphism"
    />
  );
  const ErrInput = ({name,value,}) => (
    <input
      name={name}
      type = 'text'
      value={value}
      disabled
      className="text-center w-full rounded-sm  bg-transparent text-red-600 border-none text-xs"
    />
  );

const SetData = () => {
    const [errAadhar, setErrAadhar] = useState(false);
    const [errName, setErrName] = useState(false);
    const [errEmail, setErrEmail] = useState(false);
    const [errPhone, setErrPhone] = useState(false);
    const [ifTxHash, setIfTxHash] = useState(false);
    const [txHash, setTxHash] = useState('');
    const [formData, setformData] = useState({ aadhar: "", name: "", email: "", phone: "" });

    const validateFormData = (fData) => {
        let valid = true;
        if (!aadharValidation(fData.aadhar)) {
            setErrAadhar(true);
            valid = false;
        }
        if (!nameValidation(fData.name)) {
            setErrName(true);
            valid = false;
        }
        if (!emailValidation(fData.email)) {
            setErrEmail(true);
            valid = false;
        }
        if (!phoneValidation(fData.phone)) {
            setErrPhone(true);
            valid = false;
        }
        if (valid) {
            setErrName(false); setErrAadhar(false); setErrEmail(false); setErrPhone(false);
        }
        return valid;
    }

    const handleChange = (e, name) => {
        setformData((prevState) => ({ ...prevState, [name]: e.target.value }));
    }

    const handleSubmit = async () => {
        if (validateFormData(formData)) {
            const res = await setData(formData);
            setTxHash("https://sepolia.etherscan.io/tx/" + res);
            setIfTxHash(true);
        } else {
            console.log("Data not Valid.");
        }
    }

    return (
        <div>
            <Input placeholder="Aadhar Number" name="aadhar" type="text" handleChange={handleChange} />
            {errAadhar && <ErrInput name="errAadhar" value="*Invalid Aadhar." />}
            <Input placeholder="Name" name="name" type="text" handleChange={handleChange} />
            {errName && <ErrInput name="errAadhar" value="*Invalid Name." />}
            <Input placeholder="Email" name="email" type="text" handleChange={handleChange} />
            {errEmail && <ErrInput name="errAadhar" value="*Invalid Email." />}
            <Input placeholder="Phone Number" name="phone" type="text" handleChange={handleChange} />
            {errPhone && <ErrInput name="errAadhar" value="*Invalid Phone." />}
            <div className="h-[1px] w-full bg-gray-400 my-2" />
            <button
                type="button" onClick={handleSubmit} className="text-white text-3xl w-full mt-2 border-[1px] p-2 border-[#3d4f7c] hover:bg-[#3d4f7c] rounded-full cursor-pointer">
                Submit Your Details
            </button>
            {ifTxHash &&
                <div className='blue-glassmorphism my-3 text-center '>
                    <a href={txHash} target="_blank">Transaction Successfull. View on Etherscan.</a>
                </div>}
        </div>
    )
}

export default SetData;