import {useState} from 'react';
import SetData from './SetData';
import GetData from './GetData';



const Home = () => {
  const[get,setGet] = useState(false); 
  const [btnText,setBtnText] = useState('Fetch your KYC Detail?');

  const handleGet = () => {
    if(get)setBtnText("Fetch your KYC Detail?");
    else setBtnText('Submit your KYC Detail?');
    setGet(!get);
  }

  return (
    <div className='mx-10 h-screen'>
      <div className='text-center text-white text-4xl white-glassmorphism font-bold hover:bg-[#3d4f7c] gradient-bg-KYC' onClick={handleGet}>{btnText}</div>
      {!get ? <SetData/> : <GetData/>}
    </div>
  );
}

export default Home;