import React, { useState } from 'react';
import './Home.css';

import {getTotalSupply, transferToken, mint} from '../../contract/index';  


const Home = () => {
    const [result , setResult] = useState(false);
    const [msg, setMsg] = useState('');
    let reply = 'No result currently.';

    const handleMint =async () => { 
        const address = document.getElementById('add').value;
        const amt = document.getElementById('amt').value;
        const res =await mint(address,amt);
        setMsg("https://sepolia.etherscan.io/tx/"+res);
        setResult(true);
    }
    
    const handleTransfer = async () => {
        const address1 = document.getElementById('add').value;
        const amt = document.getElementById('amt').value;
        const res =await transferToken(address1,amt);
        setMsg("https://sepolia.etherscan.io/tx/"+res);
        setResult(true);
    }

    const handleSupply = async () => {
        const bal =await getTotalSupply();
        setMsg('Total Supply is: '+bal);
        setResult(true);
    }

    return (
        <div className='Container'>
            <input id='add' type='text' className='inputAddress' placeholder='Address to mint / Addres to Transfer From' />
            <input id='amt' type='text' className='inputAmount' placeholder='Amount to send / Address to send' />
            <div className='btnContainer'>
            <button onClick={handleSupply} className='btnSupply' >Total Supply</button>
                <button onClick={handleTransfer} className='btnTransfer' >Transfer Tokens</button>
                <button onClick={handleMint} className='btnMint' >Mint Tokens</button>
            </div>
            {
                result && (
                    <div className='resDiv'>
                        <input className='resIp' type='text' value={msg} disabled />
                    </div>
                )
            }
        </div>
    )
}

export default Home;