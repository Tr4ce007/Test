import React from "react";
import './Navbar.css';

const Navbar = () => {
    return (
        <div className="connectDiv">
            <input className='titleText' value ='ERC20 API' disabled/>
            <button className="connectBtn">Connect</button>
        </div>
    );
};

export default Navbar;
