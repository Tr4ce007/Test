import { ConnectButton } from '@rainbow-me/rainbowkit';

export const Btn = () => {
  return <ConnectButton />;
};